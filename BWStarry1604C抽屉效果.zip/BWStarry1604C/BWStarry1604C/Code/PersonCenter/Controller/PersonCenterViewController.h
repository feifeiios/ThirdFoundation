//
//  PersonCenterViewController.h
//  BWStarry1604C
//
//  Created by 李非非 on 2018/7/9.
//  Copyright © 2018年 移动学院. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonCenterViewController : BaseViewController

@end
