//
//  Url.h
//  BWStarry1604C
//
//  Created by 李非非 on 2018/7/5.
//  Copyright © 2018年 移动学院. All rights reserved.
//

#ifndef Url_h
#define Url_h

#define HOME_URL @"http://127.0.0.1:3000/users/home"

#endif /* Url_h */
